package com.hadistudios.fixstore

object AppConstants {

    const val USER_NAME = "USER_NAME"
    const val USER_ID = "USER_ID"

}